#include <stdio.h>
#include <stdlib.h>

#include "SDL2/SDL.h"
#include <SDL2/SDL_ttf.h>

#include "Jeu.h"



void Jouer(game *myGame,font mFont){

    // Variable pour la boucle de jeu (tant qu'on joue).
    gameState stateGame;
    stateGame.g_bRunning = 1;

    // Struct pour les raquettes.
    SDL_Rect raquette1;
    SDL_Rect raquette2;

    // Initialisation des positions et tailles des raquettes.
    initialiserRaquette(&raquette1,10,(SCREEN_HEIGHT/2-10),RAQUETTE_WIDTH,RAQUETTE_HEIGHT);
    initialiserRaquette(&raquette2,SCREEN_WIDTH-30,(SCREEN_HEIGHT/2)-10,RAQUETTE_WIDTH,RAQUETTE_HEIGHT);

    // La balle
    balle pong;
    pong.position.x = (SCREEN_WIDTH/2)-(RAQUETTE_WIDTH/2);
    pong.position.y = (SCREEN_HEIGHT/2)-(RAQUETTE_WIDTH/2);
    pong.position.w = RAQUETTE_WIDTH;
    pong.position.h = 0;
    pong.sensX = SENS_RAQUETTE;
    pong.sensY = SENS_RAQUETTE;
    pong.scoreJ1 = 0;
    pong.scoreJ2 = 0;

    // Les chaines pour l'affichage des scores
    char score1[20];
    sprintf(score1, "Score J1 : %d", pong.scoreJ1);


    char score2[20];
    sprintf(score2, "Score J2 : %d", pong.scoreJ2);

    //dessiner les raquettes
    //dessinerRaquette(myGame,&raquette1);
    //dessinerRaquette(myGame,&raquette2);

    // Callback pour le d�placement de la balle
    SDL_TimerID timer;
    timer = SDL_AddTimer(3,bougerBalle,&pong);

    //Pour les 60 fps
    unsigned int frameLimit = SDL_GetTicks() + 16;

    while(stateGame.g_bRunning){
        SDL_Event event1;

        // On mets tout le temps la position des raquettes dans la structures de la balle
        // Ceci permet de tout le temps v�rifier les collisions
        pong.raquette1 = raquette1;
        pong.raquette2 = raquette2;

        // Mettre � jour les scores des joueurs
        sprintf(score1, "Score J1 : %d", pong.scoreJ1);
        sprintf(score2, "Score J2 : %d", pong.scoreJ2);

        //Nettoyage de l'�cran
        Nettoyage(myGame);

        // Ecriture des scores
        writeSDL(myGame,mFont,score1,(SCREEN_WIDTH/2)-300,50,200,100);
        writeSDL(myGame,mFont,score2,(SCREEN_WIDTH/2)+100,50,200,100);

        // Affichage des raquettes
        dessinerRaquette(myGame,&raquette1);
        dessinerRaquette(myGame,&raquette2);

        // Affichage de la balle
        tracerCercle(myGame,pong);

        // Affichage du rendu
        SDL_RenderPresent(myGame->g_pRenderer);


        delay(frameLimit);
        frameLimit = SDL_GetTicks() + 16;


        if(SDL_PollEvent(&event1)){
            switch(event1.type){
                case SDL_QUIT: // Si on quitte nettoyage de l'�cran
                    stateGame.g_bRunning=0;
                    break;
                case SDL_KEYDOWN:
                    switch (event1.key.keysym.sym)
                    {
                        case SDLK_LEFT:  ; break;
                        case SDLK_RIGHT: ; break;
                        case SDLK_UP:
                            SetRaquetteY(&raquette1,20) ;
                            testCollisionRaquette(&raquette1);
                            break;
                        case SDLK_DOWN:
                            SetRaquetteY(&raquette1,-20) ;
                            testCollisionRaquette(&raquette1);
                            break;
                        case SDLK_z:
                            SetRaquetteY(&raquette2,20);
                            testCollisionRaquette(&raquette2);
                            break;
                        case SDLK_s:
                            SetRaquetteY(&raquette2,-20);
                            testCollisionRaquette(&raquette2);
                            break;
                    }
                    break;

                case SDL_KEYUP:;break;

                default:break;

            }
        }
    }

    // Destruction du callback
    SDL_RemoveTimer(timer);

}

void initialiserRaquette(SDL_Rect *rectangle,int x,int y,int w,int h){
    rectangle->x = x;
    rectangle->y = y;
    rectangle->w = w;
    rectangle->h = h;
}

void dessinerRaquette(game *myGame,SDL_Rect *rectangle){

    SDL_SetRenderDrawColor(myGame->g_pRenderer, 255, 255, 255, 255);

    SDL_RenderFillRect(myGame->g_pRenderer,rectangle);
}

void Nettoyage(game *myGame){
    // Fond noir
    SDL_SetRenderDrawColor(myGame->g_pRenderer,0,0,0,255);
    // Nettoyage
    SDL_RenderClear(myGame->g_pRenderer);
    // Fond blanc pour les raquettes et la balles
    SDL_SetRenderDrawColor(myGame->g_pRenderer,255,255,255,255);
}

void delay(unsigned int frameLimit){
    // Gestion des 60 fps (images/seconde)
    unsigned int ticks = SDL_GetTicks();

    if (frameLimit < ticks)
    {
        return;
    }

    if (frameLimit > ticks + 16)
    {
        SDL_Delay(16);
    }

    else
    {
        SDL_Delay(frameLimit - ticks);
    }
}


// J'ai copier l'algo ici : https://fr.wikipedia.org/wiki/Algorithme_de_trac�_d%27arc_de_cercle_de_Bresenham
// Puis je l'ai adapt� � mon code.
void tracerCercle (game *myGame,balle pong){
        int x, y, m ;
        x = 0 ;
        y = pong.position.w ;             // on se place en haut du cercle
        m = 5 - 4*pong.position.w ;
              // initialisation
            while( x <= y   ) {     // tant qu'on est dans le second octant
                    SDL_RenderDrawPoint(myGame->g_pRenderer, x+pong.position.x, y+pong.position.y ) ;
                    SDL_RenderDrawPoint(myGame->g_pRenderer,y+pong.position.x, x+pong.position.y ) ;
                    SDL_RenderDrawPoint(myGame->g_pRenderer, -x+pong.position.x, y+pong.position.y ) ;
                    SDL_RenderDrawPoint(myGame->g_pRenderer, -y+pong.position.x, x+pong.position.y ) ;
                    SDL_RenderDrawPoint(myGame->g_pRenderer, x+pong.position.x, -y+pong.position.y ) ;
                    SDL_RenderDrawPoint(myGame->g_pRenderer, y+pong.position.x, -x+pong.position.y ) ;
                    SDL_RenderDrawPoint(myGame->g_pRenderer, -x+pong.position.x, -y+pong.position.y ) ;
                    SDL_RenderDrawPoint(myGame->g_pRenderer, -y+pong.position.x, -x+pong.position.y ) ;
                    if( m > 0 ){       //choix du point F
                            y = y - 1 ;
                            m = m - 8*y ;
                    }
                    x = x + 1 ;
                    m = m + 8*x + 4 ;
            }

}


// Appel� par le callback, la balle test directement ses collisions avec les raqusttes
Uint32 bougerBalle(Uint32 intervalle,void *parametre){

    balle *positionBalle = parametre;

    // Test de collision avec la raquette du joueur 1
    if(testCollision1(positionBalle,positionBalle->raquette1) == 1){
        positionBalle->sensX *= -1;
    }else if(testCollision1(positionBalle,positionBalle->raquette1) == 0){
        //positionBalle->position.x = (SCREEN_WIDTH/2)-(positionBalle->position.w/2);
        //positionBalle->position.x = (SCREEN_HEIGHT/2)-(positionBalle->position.w/2);
        positionBalle->sensX *= -1;
    }

    // Test de collision avec la raquette du joueur 2
    if(testCollision2(positionBalle,positionBalle->raquette2) == 1){
        positionBalle->sensX *= -1;
    }else if(testCollision2(positionBalle,positionBalle->raquette2) == 0){
        //positionBalle->position.x = (SCREEN_WIDTH/2)-(positionBalle->position.w/2);
        //positionBalle->position.x = (SCREEN_HEIGHT/2)-(positionBalle->position.w/2);
        positionBalle->sensX *= -1;
    }

    // Test des collisions haut et bas de l'�cran
    if(positionBalle->position.y > SCREEN_HEIGHT-10){
        positionBalle->sensY *= -1;
    }
    if(positionBalle->position.y < 10){
        positionBalle->sensY *= -1;
    }

    // Deplacement de la balle
    positionBalle->position.x += positionBalle->sensX;
    positionBalle->position.y += positionBalle->sensY;

    positionBalle = NULL;

    return intervalle;
}

int testCollision1(balle *pong,SDL_Rect raquette1){
    // Si la balle est plus loin que la raquetteGauche
    if(pong->position.x - (pong->position.w/2) < raquette1.x+raquette1.w){
        // Si la balle est dans la raquette
        if((pong->position.y - (pong->position.w/2) > raquette1.y && pong->position.y - (pong->position.w/2) < raquette1.y + raquette1.h)){
            return 1;
        }else{
            pong->scoreJ2 += 1;
            return 0;
        }
    }else{
        return 2;
    }
}

int testCollision2(balle *pong,SDL_Rect raquette2){
    // Si la balle est plus loin que la raquetteDroite
    if(pong->position.x + (pong->position.w/2) > raquette2.x){
        // Si la balle est dans la raquette
        if((pong->position.y + (pong->position.w/2) > raquette2.y && pong->position.y - (pong->position.w/2) < raquette2.y + raquette2.h)){
            return 1;
        }else{
            pong->scoreJ1 += 1;
            return 0;
        }
    }else{
        return 2;
    }
}

void testCollisionRaquette(SDL_Rect *raquette){
    if(raquette->y < 0){
        raquette->y = 0;
    }
    if(raquette->y+raquette->h > SCREEN_HEIGHT){
        raquette->y = SCREEN_HEIGHT-raquette->h;
    }
}

// Modifie la position en Y des raquettes
void SetRaquetteY(SDL_Rect *raquette,int valeur){
    raquette->y -= valeur;
}

// Inscrire le score
void writeSDL(game *myGame,font mFont,char *text,int posX,int posY,int largeur,int hauteur) {

        // Set la couleur
        SDL_Color fontColor={255,255,255};

        // Charge la surface

            myGame->g_surface=TTF_RenderText_Blended(mFont.g_font, text, fontColor);//Charge la police


        // Si la surface est charg�
        if(myGame->g_surface){


                //D�finition du rectangle pour blitter la chaine
                SDL_Rect rectangle;
                rectangle.x=posX;//debut x
                rectangle.y=posY;//debut y
                rectangle.w=largeur; //Largeur
                rectangle.h=hauteur; //Hauteur


                // Cr�ation d'une texture par rapport � une surface
                 myGame->g_texture = SDL_CreateTextureFromSurface(myGame->g_pRenderer,myGame->g_surface);
                 //SDL_FreeSurface(myGame->g_surface); // Lib�ration de la surface

                 // Si la texture est cr��
                 if(myGame->g_texture){
                        SDL_RenderCopy(myGame->g_pRenderer,myGame->g_texture,NULL,&rectangle); // Copie du sprite gr�ce au SDL_Renderer
                        //SDL_RenderPresent(myGame->g_pRenderer); // Affichage
                 }
                 else{
                        fprintf(stdout,"�chec de cr�ation de la texture (%s)\n",SDL_GetError());
                }

        }else{
            fprintf(stdout,"�chec de creation surface pour chaine (%s)\n",SDL_GetError());
        }
}


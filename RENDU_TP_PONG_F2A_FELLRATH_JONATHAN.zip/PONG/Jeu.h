#ifndef JEU_H_INCLUDED
#define JEU_H_INCLUDED

#define SCREEN_WIDTH 1024
#define SCREEN_HEIGHT 780

#define RAQUETTE_WIDTH 20
#define RAQUETTE_HEIGHT 100
#define SENS_RAQUETTE 1

typedef struct game{

     SDL_Window *g_pWindow;
     SDL_Renderer *g_pRenderer;
     SDL_Texture *g_texture;
     SDL_Surface *g_surface;

}game;

typedef struct gameState{

    int g_bRunning;

}gameState;

typedef struct font{

    TTF_Font *g_font;

}font;

typedef struct balle{

    SDL_Rect position;
    int sensX;
    int sensY;

    // Permet � la fonction de callback de comparer les positions de la balle avec celle des raquettes
    SDL_Rect raquette1;
    SDL_Rect raquette2;

    // Permet � la fonction de callback de setter les scores des joueurs
    int scoreJ1;
    int scoreJ2;

}balle;



void Jouer(game *myGame,font mFont);

void initialiserRaquette(SDL_Rect *rectangle,int x,int y,int w,int h);
void dessinerRaquette(game *myGame,SDL_Rect *rectangle);

void tracerCercle (game *myGame,balle pong);
Uint32 bougerBalle(Uint32 intervalle,void *parametre);

int testCollision1(balle *pong,SDL_Rect raquette);
int testCollision2(balle *pong,SDL_Rect raquette);

// Test la collision haut et bas des raquettes
void testCollisionRaquette(SDL_Rect *raquette);

// Emp�che la raquette de sortir de l'�cran
void SetRaquetteY(SDL_Rect *raquette,int valeur);

void Nettoyage(game *myGame);

void delay(unsigned int frameLimit);

void writeSDL(game *myGame,font mFont,char *text,int posX,int posY,int largeur,int hauteur);

#endif // JEU_H_INCLUDED

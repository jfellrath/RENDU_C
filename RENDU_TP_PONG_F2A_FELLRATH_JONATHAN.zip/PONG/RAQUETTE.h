/*#ifndef RAQUETTE_H_INCLUDED
#define RAQUETTE_H_INCLUDED

#include <SDL2/SDL.h>

typedef struct Raquette{

    SDL_Rect rectangle;
    SDL_Color color;

}Raquette;

int GetX(SDL_Rect coord);
int GetY(SDL_Rect coord);
int GetWidth(SDL_Rect coord);
int GetHeight(SDL_Rect coord);

void SetX(SDL_Rect *coord,int  x);
void SetY(SDL_Rect *coord,int  y);
void SetWidth(SDL_Rect *coord,int w);
void SetHeight(SDL_Rect *coord,int h);
void SetRectRaquette(Raquette *raquette,int x,int y,int w,int h);

void SetColor(Raquette *raquette,SDL_Color color);

void DessinerRaquette(SDL_Renderer *myGame);

#endif // RAQUETTE_H_INCLUDED*/


#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>

#include <time.h>

#include "Jeu.h"



//Option de build dans les linker setting mettre les libSDL2main.a libSDL2.dll.a
//Dans search directory
//Option de build compiler mettre les include
//Option de build linker mettre les lib

//mettre dans build linker -lmingw32








typedef struct coordonnees{

    double x;
    double y;



}coordonnees;


int init(char *title, int xpos,int ypos,int height, int width,int flags,game *myGame, font *mFont);
void AffichageMenu(game *myGame,font mFont);
void Menu(gameState *state,game *myGame,font mFont);
void delay(unsigned int frameLimit);
void destroy(game *myGame,font *mFont);


//void writeSDL(game *myGame,font mFont,char *text,int posX,int posY,int largeur,int hauteur);



int main(int argc, char *argv[])
{

     game myGame;
     gameState state;
     font mFont;




    if(init("Chapter 1 setting up SDL",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,SCREEN_WIDTH,SCREEN_HEIGHT,SDL_WINDOW_SHOWN,&myGame,&mFont)){
                state.g_bRunning=1;
    }else{
            return 1;//something's wrong
    }


    while(state.g_bRunning){

        AffichageMenu(&myGame,mFont);

        Menu(&state,&myGame,mFont);

        //writeSDL(&myGame,mFont,"Salut",SCREEN_WIDTH/3,SCREEN_HEIGHT/3,100,100);
        // Gestion des 60 fps (1000ms/60 = 16.6 -> 16
        //delay(frameLimit);
        // frameLimit = SDL_GetTicks() + 16;
    }

         destroy(&myGame,&mFont);

         TTF_Quit();
         SDL_Quit();

  return 0;
}

void AffichageMenu(game *myGame,font mFont){
    // Ecriture des scores
    SDL_SetRenderDrawColor(myGame->g_pRenderer,0,0,0,255);
    SDL_RenderClear(myGame->g_pRenderer);
    writeSDL(myGame,mFont,"PRESS 1 TO PLAY",(SCREEN_WIDTH/2)-250,50,500,100);
    writeSDL(myGame,mFont,"PRESS 2 TO QUIT",(SCREEN_WIDTH/2)-250,150,500,100);
    SDL_RenderPresent(myGame->g_pRenderer);
}



int init(char *title, int xpos,int ypos,int height, int width,int flags,game *myGame, font *mFont){
    // Initialise tous les composants de la sdl
    if(SDL_Init(SDL_INIT_EVERYTHING)>=0)
    {
            // Si c'est un succ�s, la cr�ation de la fen�tre est possible
            myGame->g_pWindow=SDL_CreateWindow(title,xpos,ypos,height,width,flags);
            // Si la fen�tre est cr��, cr�ation d'un rendu
            if(myGame->g_pWindow!=NULL){
                myGame->g_pRenderer=SDL_CreateRenderer(myGame->g_pWindow,-1,SDL_RENDERER_ACCELERATED);
            }
    }else{
        return 0;
    }

    // Initialisation de la sdl_ttf
    if(TTF_Init() == -1)
    {
        fprintf(stderr, "Erreur d'initialisation de TTF_Init : %s\n", TTF_GetError());
        exit(EXIT_FAILURE);
    }

    // Onverture de du fichier de police ttf
    mFont->g_font=TTF_OpenFont("./assets/fonts/allstar/All Star Resort.ttf",65);

    // Si c'est un echec
    if(!mFont->g_font) {
        printf("TTF_OpenFont: %s\n", TTF_GetError());
        SDL_Delay(5000);
        exit(EXIT_FAILURE);
    }

    return 1;
}

// La boucle de jeu
void Menu(gameState *state,game *myGame,font mFont){
    SDL_Event event;

    if(SDL_PollEvent(&event)){
        switch(event.type){
            case SDL_QUIT:
                  state->g_bRunning=0;break;
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym)
                {
                    case SDLK_KP_1:
                        Jouer(myGame,mFont); break;
                    case SDLK_KP_2:
                        state->g_bRunning=0; break;
                }
                break;;

            default:break;

        }
    }
}


/* Ecrire du texte
void writeSDL(game *myGame,font mFont,char *text,int posX,int posY,int largeur,int hauteur) {

        // Set la couleur
        SDL_Color fontColor={255,0,0};

        // Charge la surface
        myGame->g_surface=TTF_RenderText_Blended(mFont.g_font, text, fontColor);//Charge la police

        // Si la surface est charg�
        if(myGame->g_surface){


                //D�finition du rectangle pour blitter la chaine
                SDL_Rect rectangle;
                rectangle.x=posX;//debut x
                rectangle.y=posY;//debut y
                rectangle.w=largeur; //Largeur
                rectangle.h=hauteur; //Hauteur


                // Cr�ation d'une texture par rapport � ne surface
                 myGame->g_texture = SDL_CreateTextureFromSurface(myGame->g_pRenderer,myGame->g_surface);
                 SDL_FreeSurface(myGame->g_surface); // Lib�ration de la surface

                 // Si la texture est cr��
                 if(myGame->g_texture){
                        SDL_RenderCopy(myGame->g_pRenderer,myGame->g_texture,NULL,&rectangle); // Copie du sprite gr�ce au SDL_Renderer
                        SDL_RenderPresent(myGame->g_pRenderer); // Affichage
                 }
                 else{
                        fprintf(stdout,"�chec de cr�ation de la texture (%s)\n",SDL_GetError());
                }

        }else{
            fprintf(stdout,"�chec de creation surface pour chaine (%s)\n",SDL_GetError());
        }
}*/






void destroy(game *myGame,font *mFont){


    if(mFont->g_font!=NULL){
        TTF_CloseFont(mFont->g_font); /* Doit �tre avant TTF_Quit() */
        mFont->g_font=NULL;
    }

    //Destroy texture
    if(myGame->g_texture!=NULL)
            SDL_DestroyTexture(myGame->g_texture);


    //Destroy render
    if(myGame->g_pRenderer!=NULL)
        SDL_DestroyRenderer(myGame->g_pRenderer);


    //Destroy window
    if(myGame->g_pWindow!=NULL)
        SDL_DestroyWindow(myGame->g_pWindow);

}













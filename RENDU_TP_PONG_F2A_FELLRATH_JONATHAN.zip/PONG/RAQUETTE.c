/*#include "RAQUETTE.h"


int GetX(SDL_Rect coord){
    return coord.x;
}
int GetY(SDL_Rect coord){
    return coord.y;
}
int GetWidth(SDL_Rect coord){
    return coord.w;
}
int GetHeight(SDL_Rect coord){
    return coord.y;
}

void SetX(SDL_Rect *coord,int x){
    coord->x = x;
}
void SetY(SDL_Rect *coord,int y){
    coord->y = y;
}
void SetWidth(SDL_Rect *coord,int w){
    coord->w = w;
}
void SetHeight(SDL_Rect *coord,int h){
    coord->h = h;
}


// Modifier les couleurs de la raquette
void SetColor(Raquette *raquette,SDL_Color color){
    raquette->color.a = color.a;
    raquette->color.b = color.b;
    raquette->color.g = color.g;
    raquette->color.r = color.r;
}
void SetColorA(Raquette *raquette,Uint8 a){
    raquette->color.a = a;
}
void SetColorR(Raquette *raquette,Uint8 r){
    raquette->color.r = r;
}
void SetColorG(Raquette *raquette,Uint8 g){
    raquette->color.g = g;
}
void SetColorB(Raquette *raquette,Uint8 b){
    raquette->color.b = b;
}
void SetRectRaquette(Raquette *raquette,int x,int y,int w,int h){
    raquette->rectangle.x = x;
    raquette->rectangle.y = y;
    raquette->rectangle.w = w;
    raquette->rectangle.h = h;
}*/






#ifndef RAQUETTE_H_INCLUDED
#define RAQUETTE_H_INCLUDED

#include <SDL2/SDL.h>

typedef struct RAQUETTE{

    SDL_Rect rectangleSource;
    SDL_Rect rectangleDestination;

}RAQUETTE;

void DeplacerRaquette(RAQUETTE *raquette,int valeur);
void InitRaquetteSource(RAQUETTE *raquette,int w, int h, int x, int y);
void InitRaquetteDestination(RAQUETTE *raquette,int w, int h, int x, int y);

#endif // RAQUETTE_H_INCLUDED

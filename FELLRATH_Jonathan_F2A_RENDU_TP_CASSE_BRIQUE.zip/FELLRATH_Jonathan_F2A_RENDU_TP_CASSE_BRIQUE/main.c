#include <stdio.h>
#include <stdlib.h>

#include "RAQUETTE.h"
#include "Mur.h"
#include "Balle.h"

#include <SDL2/SDL_image.h>
#include <time.h>

#define SCREEN_WIDTH 1024
#define SCREEN_HEIGHT 780


//Option de build dans les linker setting mettre les libSDL2main.a libSDL2.dll.a
//Dans search directory
//Option de build compiler mettre les include
//Option de build linker mettre les lib

//mettre dans build linker -lmingw32

typedef struct game{


     SDL_Window *g_pWindow;
     SDL_Renderer *g_pRenderer;
     SDL_Texture *g_texture;
     SDL_Surface *g_surface;


}game;

typedef struct gameState{

    int g_bRunning;
    int left;
    int right;


}gameState;


typedef struct coordonnees{

    double x;
    double y;



}coordonnees;


int init(char *title, int xpos,int ypos,int height, int width,int flags,game *myGame);
void handleEvents(gameState *state,RAQUETTE *);

// Dessine les murs;
void cutBitmapTextureMur(game *myGame,gameState state,Mur *,char *text);

// Dessine la raquette et la balle
void cutBitmapTexture(game *myGame,gameState state,SDL_Rect src,SDL_Rect dest,char *text);

void delay(unsigned int frameLimit);
void destroyTexture(game *myGame);
void destroy(game *myGame);




int main(int argc, char *argv[])
{

     game myGame;
     gameState state;
     srand(time(0));

     RAQUETTE Raquette;
     InitRaquetteSource(&Raquette,128,32,0,0);
     InitRaquetteDestination(&Raquette,128,32,(SCREEN_WIDTH/2)-64,SCREEN_HEIGHT-64);

     BALLE balle;
     InitBalleSource(&balle,0,0,24,24);
     InitBalleDestination(&balle,(SCREEN_WIDTH/2)-12,550,24,24);
     InitBalleSens(&balle,1,-1);



     /*SDL_Rect sourceRaquette;
     sourceRaquette.x = 0;
     sourceRaquette.y = 0;
     sourceRaquette.w = 128;
     sourceRaquette.h = 32;

     SDL_Rect rectangleDest;
     rectangleDest.x = (SCREEN_WIDTH/2)-64;
     rectangleDest.y = SCREEN_HEIGHT-64;
     rectangleDest.w = 128;
     rectangleDest.h = 32;*/



    Mur tab[16*16];
    InitTableauMur(tab,FALSE);






    //Pour les 60 fps
    unsigned int frameLimit = SDL_GetTicks() + 16;


    SDL_TimerID timer;
    timer = SDL_AddTimer(5,bougerBalle,&balle);


    if(init("Chapter 1 setting up SDL",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,SCREEN_WIDTH,SCREEN_HEIGHT,SDL_WINDOW_SHOWN,&myGame)){

                state.g_bRunning=1;


    }else{

            return 1;//something's wrong

    }


    state.right=1;
    state.left=0;

    BOOL afficherBrique = TRUE;

    while(state.g_bRunning){

        cutBitmapTextureMur(&myGame,state,tab,"./assets/bricks.png");

        // Affichage de la raquette
        cutBitmapTexture(&myGame,state,Raquette.rectangleSource,Raquette.rectangleDestination,"./assets/paddle.png");

        // Affichage de la balle
        cutBitmapTexture(&myGame,state,balle.rectangleSource,balle.rectangleDestination,"./assets/ball.png");

        TestCollision(&balle,tab,Raquette);

        // Evenement
        handleEvents(&state,&Raquette);




        // Gestion des 60 fps (1000ms/60 = 16.6 -> 16
            delay(frameLimit);
            frameLimit = SDL_GetTicks() + 16;

            SDL_RenderPresent(myGame.g_pRenderer); // Affichage

            SDL_RenderClear(myGame.g_pRenderer);


    }

        // Destruction du callback
        SDL_RemoveTimer(timer);

        SDL_FreeSurface(myGame.g_surface); // Lib�ration de la ressource occup�e par le sprite

        destroy(&myGame);

        SDL_Quit();




  return 0;
}


int init(char *title, int xpos,int ypos,int height, int width,int flags,game *myGame){


    //initialize SDL

    if(SDL_Init(SDL_INIT_EVERYTHING)>=0)
    {
            //if succeeded create our window
            myGame->g_pWindow=SDL_CreateWindow(title,xpos,ypos,height,width,flags);
            //if succeeded create window, create our render
            if(myGame->g_pWindow!=NULL){
                myGame->g_pRenderer=SDL_CreateRenderer(myGame->g_pWindow,-1,SDL_RENDERER_ACCELERATED);
                SDL_SetRenderDrawColor(myGame->g_pRenderer, 0, 0, 0, 255);
                SDL_RenderClear(myGame->g_pRenderer);

            }


    }else{


        return 0;
    }




    return 1;


}

void handleEvents(gameState *state,RAQUETTE *raquette){


    SDL_Event event;

    if(SDL_PollEvent(&event)){
        switch(event.type){
        case SDL_QUIT:
              state->g_bRunning=0;break;
        case SDL_KEYDOWN:
                        switch (event.key.keysym.sym)
                            {
                                case SDLK_LEFT:
                                    DeplacerRaquette(raquette,-10);
                                    break;
                                case SDLK_RIGHT:
                                    DeplacerRaquette(raquette,10);
                                    break;
                                case SDLK_UP:    ; break;
                                case SDLK_DOWN:  ; break;
                            }
                            break;

        case SDL_KEYUP:;break;

        default:break;

        }
    }


}




void cutBitmapTextureMur(game *myGame,gameState state,Mur *tabMur,char *text){

        //SDL_Rect rectangleDest;
        //SDL_Rect rectangleSource;


        myGame->g_surface = IMG_Load(text);//Chargement de l'image png

        if(!myGame->g_surface) {
            fprintf(stdout,"IMG_Load: %s\n", IMG_GetError());
            // handle error
        }

        if(myGame->g_surface){


                 myGame->g_texture = SDL_CreateTextureFromSurface(myGame->g_pRenderer,myGame->g_surface); // Pr�paration du sprite
                 //SDL_FreeSurface(myGame->g_surface); // Lib�ration de la ressource occup�e par le sprite

                if(myGame->g_texture){


                    //SDL_QueryTexture(myGame->g_texture,NULL,NULL,NULL,NULL);

                    /*rectangleSource.x = 0;
                    rectangleSource.y = 0;
                    rectangleSource.w = 64;
                    rectangleSource.h = 24;*/

                    /*rectangleDest.x = (SCREEN_WIDTH/2)-64;
                    rectangleDest.y = SCREEN_HEIGHT-64;
                    rectangleDest.w = 128;
                    rectangleDest.h = 32;*/

                    int i;
                    i=0;


                    for(i = 0; i<16*16;i++){
                        if(tabMur[i].casse == FALSE){
                            SDL_Rect destination = tabMur[i].MurDest;
                            SDL_Rect source = tabMur[i].MurSource;

                            SDL_RenderCopy(myGame->g_pRenderer,myGame->g_texture,&source,&destination);
                        }
                    }

                    /*if(state.right)
                        SDL_RenderCopy(myGame->g_pRenderer,myGame->g_texture,&rectangleSource,&rectangleDest); // Copie du sprite gr�ce au SDL_Renderer
                    if(state.left)
                        SDL_RenderCopyEx(myGame->g_pRenderer,myGame->g_texture,&rectangleSource,&rectangleDest,0,0,SDL_FLIP_HORIZONTAL);*/

                    //SDL_FLIP_NONE
                    //SDL_FLIP_HORIZONTAL
                    //SDL_FLIP_VERTICAL





                }

                else{
                        fprintf(stdout,"�chec de cr�ation de la texture (%s)\n",SDL_GetError());
                }



        }else{
            fprintf(stdout,"�chec de chargement du sprite (%s)\n",SDL_GetError());
        }


    destroyTexture(myGame);

}

void cutBitmapTexture(game *myGame,gameState state,SDL_Rect src,SDL_Rect dest,char *text){

        //SDL_Rect rectangleDest;
        //SDL_Rect rectangleSource;


        myGame->g_surface = IMG_Load(text);//Chargement de l'image png

        if(!myGame->g_surface) {
            fprintf(stdout,"IMG_Load: %s\n", IMG_GetError());
            // handle error
        }

        if(myGame->g_surface){


                 myGame->g_texture = SDL_CreateTextureFromSurface(myGame->g_pRenderer,myGame->g_surface); // Pr�paration du sprite
                 //SDL_FreeSurface(myGame->g_surface); // Lib�ration de la ressource occup�e par le sprite

                if(myGame->g_texture){


                    //SDL_QueryTexture(myGame->g_texture,NULL,NULL,NULL,NULL);

                    /*rectangleSource.x = 0;
                    rectangleSource.y = 0;
                    rectangleSource.w = 64;
                    rectangleSource.h = 24;*/

                    /*rectangleDest.x = (SCREEN_WIDTH/2)-64;
                    rectangleDest.y = SCREEN_HEIGHT-64;
                    rectangleDest.w = 128;
                    rectangleDest.h = 32;*/


                    SDL_RenderCopy(myGame->g_pRenderer,myGame->g_texture,&src,&dest);



                    /*if(state.right)
                        SDL_RenderCopy(myGame->g_pRenderer,myGame->g_texture,&rectangleSource,&rectangleDest); // Copie du sprite gr�ce au SDL_Renderer
                    if(state.left)
                        SDL_RenderCopyEx(myGame->g_pRenderer,myGame->g_texture,&rectangleSource,&rectangleDest,0,0,SDL_FLIP_HORIZONTAL);*/

                    //SDL_FLIP_NONE
                    //SDL_FLIP_HORIZONTAL
                    //SDL_FLIP_VERTICAL





                }

                else{
                        fprintf(stdout,"�chec de cr�ation de la texture (%s)\n",SDL_GetError());
                }



        }else{
            fprintf(stdout,"�chec de chargement du sprite (%s)\n",SDL_GetError());
        }


    destroyTexture(myGame);

}

void delay(unsigned int frameLimit){
    // Gestion des 60 fps (images/seconde)
    unsigned int ticks = SDL_GetTicks();

    if (frameLimit < ticks)
    {
        return;
    }

    if (frameLimit > ticks + 16)
    {
        SDL_Delay(16);
    }

    else
    {
        SDL_Delay(frameLimit - ticks);
    }
}




void destroy(game *myGame){

    //Destroy render
    if(myGame->g_pRenderer!=NULL)
        SDL_DestroyRenderer(myGame->g_pRenderer);


    //Destroy window
    if(myGame->g_pWindow!=NULL)
        SDL_DestroyWindow(myGame->g_pWindow);

}



void destroyTexture(game *myGame){

    //Destroy texture
    if(myGame->g_texture!=NULL)
            SDL_DestroyTexture(myGame->g_texture);


}











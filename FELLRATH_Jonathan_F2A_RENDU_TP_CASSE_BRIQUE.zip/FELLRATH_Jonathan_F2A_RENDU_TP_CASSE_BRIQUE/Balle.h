#ifndef BALLE_H_INCLUDED
#define BALLE_H_INCLUDED

#include "SDL2/SDL.h"
#include "Mur.h"
#include "RAQUETTE.h"

typedef struct BALLE{

    SDL_Rect rectangleSource;
    SDL_Rect rectangleDestination;
    int sensX;
    int sensY;

}BALLE;

InitBalleSource(BALLE *,int,int,int,int);
InitBalleDestination(BALLE *,int,int,int,int);
InitBalleSens(BALLE *balle,int x,int y);

void TestCollision(BALLE *balle,Mur *mur,RAQUETTE raquette);

Uint32 bougerBalle(Uint32 intervalle,void *parametre);

#endif // BALLE_H_INCLUDED

#include "RAQUETTE.h"

void DeplacerRaquette(RAQUETTE *raquette,int valeur){
    raquette->rectangleDestination.x += valeur;
}

void InitRaquetteSource(RAQUETTE *raquette,int w, int h, int x, int y){
    raquette->rectangleSource.h = h;
    raquette->rectangleSource.w = w;
    raquette->rectangleSource.x = x;
    raquette->rectangleSource.y = y;
}

void InitRaquetteDestination(RAQUETTE *raquette,int w, int h, int x, int y){
    raquette->rectangleDestination.h = h;
    raquette->rectangleDestination.w = w;
    raquette->rectangleDestination.x = x;
    raquette->rectangleDestination.y = y;
}

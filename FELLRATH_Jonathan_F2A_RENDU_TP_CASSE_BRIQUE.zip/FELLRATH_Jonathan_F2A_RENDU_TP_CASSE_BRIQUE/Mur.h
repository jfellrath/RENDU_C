#ifndef MUR_H_INCLUDED
#define MUR_H_INCLUDED

#include <SDL2/SDL.h>

#define LARGEURBRIQUE 64
#define HAUTEURBRIQUE 24

typedef enum {FALSE,TRUE}BOOL;

typedef struct Mur{

    SDL_Rect MurSource;
    SDL_Rect MurDest;
    BOOL casse; // Savoir si le mur est cass� ou non


}Mur;

void InitTableauMur(Mur *mur,BOOL value);


#endif // MUR_H_INCLUDED

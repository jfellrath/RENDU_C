#include "Balle.h"



InitBalleSource(BALLE *balle,int x,int y,int w,int h){
    balle->rectangleSource.x = x;
    balle->rectangleSource.y = y;
    balle->rectangleSource.w = w;
    balle->rectangleSource.h = h;
}

InitBalleDestination(BALLE *balle,int x,int y,int w,int h){
    balle->rectangleDestination.x = x;
    balle->rectangleDestination.y = y;
    balle->rectangleDestination.w = w;
    balle->rectangleDestination.h = h;
}

InitBalleSens(BALLE *balle,int x, int y){
    balle->sensX = x;
    balle->sensY = y;
}

// Appel� par le callback, la balle test directement ses collisions avec les raqusttes
Uint32 bougerBalle(Uint32 intervalle,void *parametre){

    BALLE *positionBalle = parametre;

    // Deplacement de la balle
    positionBalle->rectangleDestination.x += positionBalle->sensX;
    positionBalle->rectangleDestination.y += positionBalle->sensY;

    positionBalle = NULL;

    return intervalle;
}

void TestCollision(BALLE *balle,Mur *mur,RAQUETTE raquette){
    int i = 0;
    // Pour chaque brique
    for(i=0;i<16*16;i++){
        if(mur[i].casse != TRUE){
            // Collision avec le bards bas d'une brique
            if(mur[i].MurDest.x < balle->rectangleDestination.x+24
               && mur[i].MurDest.x+64 > balle->rectangleDestination.x
               && mur[i].MurDest.y+24 > balle->rectangleDestination.y){
                balle->sensY = 1;
                mur[i].casse = TRUE;
                    break;
            }
            // Collision avec le bords Gauche d'une brique
            /*else if(balle->rectangleDestination.x+24 > mur[i].MurDest.x
               && balle->rectangleDestination.y+4 > mur[i].MurDest.y
               && balle->rectangleDestination.y+20 < mur[i].MurDest.y+24){
                balle->sensX = -1;
                mur[i].casse = TRUE;
            }
            // Collision avec le bords droit d'une brique
            else if(balle->rectangleDestination.x < mur[i].MurDest.x+64
               && balle->rectangleDestination.y+4 > mur[i].MurDest.y
               && balle->rectangleDestination.y+20 < mur[i].MurDest.y+24){
                balle->sensX = 1;
                mur[i].casse = TRUE;
            }*/
        }

    }

    // Collision avec la raquette
    if(balle->rectangleDestination.x+24 > raquette.rectangleDestination.x && balle->rectangleDestination.x < raquette.rectangleDestination.x+128
       && balle->rectangleDestination.y+24 > raquette.rectangleDestination.y){

        balle->sensY = -1;
    }

    // Collision avec le bords droit
    if(balle->rectangleDestination.x+24 > 1024){
        balle->sensX = -1;
    }
    // Collision avec le bords gauche
    if(balle->rectangleDestination.x < 0){
        balle->sensX = 1;
    }
    // Collision avec le bords haut de l'ecran
    if(balle->rectangleDestination.y < 0){
        balle->sensY = 1;
    }
    // Collision avec le bords bas de l'ecran
    if(balle->rectangleDestination.y+24 > 780){
        InitBalleDestination(balle,(1024/2)-12,550,24,24);
        balle->sensX = balle->sensX * -1;
        balle->sensY = -1;
    }
}

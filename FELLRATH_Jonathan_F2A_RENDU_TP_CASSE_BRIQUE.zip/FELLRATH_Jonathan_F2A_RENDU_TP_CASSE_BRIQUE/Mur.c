#include "Mur.h"

// But: Initialiser un mur

// Entree:
    // Le mur
    // La position x
    // La position Y
    // La largeur
    // La hauteur

// Sortie: Un mur initialis�


// But remplir un tableau simple des positions de chaque mur
// La fonction appel la m�thode d'initialisation d'un mur.

// Entree:
    // Le tableau
    // Le mur � mettre dans le tableau de mur
    // Un booleen pour indiquer si le mur est casse ou non

// Sortie: Un tableau simple setter avec les valeurs de chaque mur

void InitTableauMur(Mur *mur,BOOL value){
    int i,j,x,y,v,couleur;
    i = j = x = y = v = 0;
    couleur = 1;

    for(i = 0;i<15;i++){
        for(j = 0; j<16;j++){
            if(couleur == 0){
                mur[v].MurSource.x = 0;
                mur[v].MurSource.y = 0;
                mur[v].MurSource.w = LARGEURBRIQUE;
                mur[v].MurSource.h = HAUTEURBRIQUE;
            }else if(couleur == 1){
                mur[v].MurSource.x = LARGEURBRIQUE;
                mur[v].MurSource.y = 0;
                mur[v].MurSource.w = LARGEURBRIQUE;
                mur[v].MurSource.h = HAUTEURBRIQUE;
            }else if(couleur == 2){
                mur[v].MurSource.x = 0;
                mur[v].MurSource.y = HAUTEURBRIQUE;
                mur[v].MurSource.w = LARGEURBRIQUE;
                mur[v].MurSource.h = HAUTEURBRIQUE;
            }else if(couleur == 3){
                mur[v].MurSource.x = LARGEURBRIQUE;
                mur[v].MurSource.y = HAUTEURBRIQUE;
                mur[v].MurSource.w = LARGEURBRIQUE;
                mur[v].MurSource.h = HAUTEURBRIQUE;
            }

            couleur = rand()%4;

            if(couleur > 4){
                //couleur = 1;
            }


            mur[v].MurDest.x = x;
            mur[v].MurDest.y = y;
            mur[v].MurDest.w = LARGEURBRIQUE;
            mur[v].MurDest.h = HAUTEURBRIQUE;
            mur[v].casse = value;
            x+= LARGEURBRIQUE;
            v++;
        }

        x = 0;
        y+= HAUTEURBRIQUE;

    }
}
